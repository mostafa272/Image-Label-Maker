=== Image Label Maker ===
Contributors: Mostafa Shahiri
Tags: watermark, images, label, png images, jpg image, transparent png, transparency, shortcode, photo
Requires at least: 3.6.1
Tested up to: 4.8.x
Stable tag: 3.4.0

The Image Label Maker is a simple plugin to merge images together and creates a new image with label or watermark.

== Description ==

The Image Label Maker is a simple plugin to merge images together and creates a new image with label or watermark. It works with PNG and JPG images and you can add an
image as label image to another image (main image). This plugin has very flexible options that enables you to generate images with watermark or label.
In admin panel, you can control:

1) access level for users or guests
2) uploading images size
3) asking question to prevent bots
4) storing time for created images

In frontend input form, users can control and customize:

1)  place of label image
2) distance of label image from corners
3) amounts of transparency for label image
4) type of output image (jpg or png)

To use this plugin, after activation of the plugin, you should place [image_label_maker_form] shortcode in your posts.

== Installation ==

Upload the Image Label Maker plugin to your blog, Activate it.Then place [image_label_maker_form] shortcode in your posts to load it.

== Changelog ==

= 1.0 =
First release
